import { getSupabaseClient } from "@/lib/supabase";
import type { AuthError, Session } from "@supabase/supabase-js";

export type AuthResult = { session: Session | null; error: AuthError | null };

export const authService = {
  async signIn(email: string, password: string) {
    const { data, error } = await getSupabaseClient().auth.signInWithPassword({ email: email.trim(), password });
    return { session: data.session, error } satisfies AuthResult;
  },

  async signUp(input: { email: string; password: string; name: string; phone: string }) {
    const { data, error } = await getSupabaseClient().auth.signUp({
      email: input.email.trim(),
      password: input.password,
      options: { data: { full_name: input.name.trim(), phone: input.phone.trim() } },
    });
    return { session: data.session, error } satisfies AuthResult;
  },

  async signOut() {
    const { error } = await getSupabaseClient().auth.signOut();
    return { error };
  },

  async sendPasswordReset(email: string) {
    const { error } = await getSupabaseClient().auth.resetPasswordForEmail(email.trim());
    return { error };
  },

  async verifyPasswordReset(email: string, token: string) {
    const { data, error } = await getSupabaseClient().auth.verifyOtp({
      email: email.trim(),
      token: token.trim(),
      type: "recovery",
    });
    return { session: data.session, error } satisfies AuthResult;
  },

  async updatePassword(password: string) {
    const { error } = await getSupabaseClient().auth.updateUser({ password });
    return { error };
  },
};